---
  title: Valid
  description: Valid
  time: 345
  tags: [tutorial>beginner, operating-system>ios, operating-system>android, products>sap-web-ide]
  primary_tag: products>sap-web-ide
---

## Prerequisites
 - Prerequisite 1
 - Prerequisite 2

## Details
### You will learn
  - How to do something
  - Why this technology is helpful

Add additional information: Background information, longer prerequisites

---

[ACCORDION-BEGIN [Step 1: ](Step 1)]

[ACCORDION-END]

[ACCORDION-BEGIN [Step 2: ](Step 2)]

[ACCORDION-END]

---
