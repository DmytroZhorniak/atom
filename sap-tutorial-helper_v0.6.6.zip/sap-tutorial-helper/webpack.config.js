const os = require('os');
const path = require('path');
const glob = require('glob');
const webpack = require('webpack');

const { name: PLUGIN_NAME } = require('./package');

const specs = glob.sync('./tests/*.js');

const entry = {
  'dist/main.js': './lib',
};

specs.reduce((result, filePath) => {
  entry[`spec/${path.basename(filePath)}`] = filePath;

  return entry;
}, entry);

const ATOM_HOME = process.env.ATOM_HOME || path.join(os.homedir(), '.atom');

module.exports = {
  mode: process.env.NODE_ENV || 'development',
  entry,
  output: {
    path: __dirname,
    filename: './[name]',
    library: '',
    libraryTarget: 'commonjs',
  },
  resolve: {
    alias: {
      static: path.resolve(__dirname, 'static/'),
      'static-fallback': path.resolve(__dirname, 'static-fallback/'),
    },
  },
  module: {
    rules: [
      {
        test: /\.m?js$/,
        exclude: /(node_modules)/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: [
              ['@babel/preset-env', {
                targets: {
                  chrome: 69,
                },
              }],
              '@babel/preset-react',
              'minify',
            ],
            plugins: [
              '@babel/plugin-proposal-export-default-from',
              'transform-function-bind',
            ],
          },
        },
      },
    ],
  },
  plugins: [
    new webpack.DefinePlugin({
      PLUGIN_NAME: JSON.stringify(PLUGIN_NAME),
      PLUGIN_HOME: JSON.stringify(path.join(ATOM_HOME, 'packages', PLUGIN_NAME)),
    }),
  ],
  target: 'electron-renderer',
  externals: {
    atom: 'commonjs atom',
    'node-fetch': 'node-fetch',
  },
};
