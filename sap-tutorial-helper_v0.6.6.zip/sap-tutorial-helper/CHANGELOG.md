#### v0.0.13

- _New SAP Tutorial_:
    - Added hint to tags list: _When finished press RETURN_
    - Displayed each sentence in a hint on a new line
    - Improved hint: _Primary tag is required! Note: use TAB for selection_ changed to _Primary tag is required! Note: Use TAB for selection_
- _Validation_:
    - Improved error notification: _Errors on lines:_ changed to _Errors on these lines:_
- _Push to Production_:
    - Save all automatically before pushing to production
    - Fixed bug when user uses production repo instead of fork
- _Commit Selection_:
    - Changed order of commands from _commit, fetch, pull, push_ to _fetch, pull, commit, push_ to avoid extra merge commits
    - Save all automatically before commit

#### v0.0.14
- Tags are loaded from Production repository
- Spellcheck whitelist is loaded from Production repository

#### v0.0.15
- Ask for commit message in _Push to Production_

#### v0.0.16
- Change QA Green URL for preview
- Fix line endings in install/unix.sh
- fix Push to Production (keep `this.isProduction` up-to-date)
- Push to Production: Enable it on multiple files
- Validation: Display line numbers in right order

#### v0.0.17
- Update text strings (see attachment to the https://issues.wdf.sap.corp/browse/DEVMS-1464)
- Extract path to fork dynamically
- Fix live update delay for preview

#### v0.0.18
- Auto-update detects new version even if it was already fetched to Tutorials-Contribution, but not installed yet

#### v0.0.19
- Detect new version using version number from file name

#### v0.0.20
- Group menu items
- Fix Production repo recognized as fork

#### v0.0.21
- Change `git checkout` to `git pull` in auto-update
- Fix extra files copied to Production if tutorial folder with contents selected for push
- Fix `upstream/master not what we can merge`

#### v0.0.27
- Changed some strings in push to production
- Fixed bug on Mac: `New SAP tutorial` menu option fails on Mac with permission denied error

#### v0.0.28
- Remove "no useless terms in link terms"
- consider SAP internal links as invalid

#### v0.0.31
- Automate build process

#### v0.0.40
- Prevent cmd window from closing after plugin installation

#### v0.0.41
- Commit deleted files in Push to Production

#### v0.1.0
- Validate tutorials before committing

#### v0.1.2
- Fix caching issue when loading tags from Production repo

#### v0.1.3
- Fix pushing more than 3 tutorials at once
- Fix git commands used with path with spaces

#### v0.1.4
- Support shortcut for New SAP Tutorial command

#### v0.1.5
- Support search for tags with numbers

#### v0.1.6
- Fix: plain text links ignored in Prerequisites and any text before Steps

#### v0.1.7
- Enable loading new version from development repository

#### v0.1.8
- Fix link checker in inline code

#### v0.1.9
- Fix link checker in indented code blocks, update strings in the _New SAP Tutorial_ wizard

#### v0.1.10
- Improve validation messages
- Allow trailing semicolons in tags (_New SAP Tutorial_ wizard)

#### v0.1.11
- Fix link extraction

#### v0.1.12
- Update _New SAP Tutorial_ wizard

#### v0.1.13
- Fix validation check result shows `function() [native code]`
- Fix some link check results shown on the 1st line
- Fix no errors shown in case there are only link errors and no other error types

#### v0.1.14
- Fix primary tag validation

#### v0.1.15
- Fix primary tag validation (for tags with commas)

#### v0.1.16
- Fix unstable data loading (Syntax error. Unexpected JSON input in tags.json)

#### v0.1.17
- Validation. Start notification should be visible until validation ends

#### v0.1.18
- Fix: file name checker works incorrectly if tutorial path includes Tutorials AND Tutorials-Contribution

#### v0.1.19
- Fix validation before Push to QA / Push to Production shows false positives 

#### v0.1.20
- Fix spellchecking of words like _14-day_ and _CDS-based_

#### v0.1.21
- Fix when file name is different from folder name the error is not shown

#### v0.1.22
- Fix not all tutorials pushed to QA, but all pushed to Production

#### v0.1.23
- Fix _Push to Production_ continues working despite of committing to QA cancelled

#### v0.1.24
- Fix tests

#### v0.1.25
- Implement batch script for setting node executable in PATH for Windows

#### v0.2.0
- Save scrolling position in the preview when preview reloads

#### v0.2.1
- Add one more attempt to check a link

#### v0.2.2
- DEVMS-1832

#### v0.2.3
- cover preview command with the tests

#### v0.2.4
- Replace unreliable module for copying
- Prevent the module from running several similar actions at once

#### v0.2.5
- Remove node_modules before installing dependencies in auto-update and installation scripts

#### v0.2.6
- Fix: commit dialog closed mistakenly when user leaves current Atom window

#### v0.3.0
- Add context menu for inserting markdown templates

#### v0.3.1
- Show menu in rules.vr file also
- Add one more validation template

#### v0.4.0
- implement conditional steps validation 

#### v0.4.1
- remove unneeded dependency

#### v0.4.2
- 1. Improve image link validation:
  [My image](image.png)  OK  We still have to make sure it exists
- 2. Improve tutorial link validation
  [tutorial](abc-xyz.html) Incorrect link: If you want link to tutorial, use tutorial name without ".html". If you want external link, use full URL with "http/https"
  [tutorial](abc-xyz)  link check QA when in QA / production when in production / plugin QA

#### v0.4.3
- revert VALIDATION related changes

#### v0.4.4
- update error messages for options validation

#### v0.4.5
- add _Option Tab_ context menu item

#### v0.4.6
- move sync with remote to the beginning of push to prod
- change error message

#### v0.4.7
- change image link detecting regexp in accordance to backend

#### v0.4.8
- run _npm audit fix_ in installation script

#### v0.4.9
- show tutorial name in error message
- fix context menu items don't work in rules.vr file
- fix link checking (tutorial names)
- suppress commands output (installation scripts)
- show auto update in progress message

#### v0.4.10
- fix tutorial link detection

#### v0.4.11
- installation scripts: handle the case if no packages folder found inside of ~/.atom 

#### v0.4.12
- Fix Push to Production won't work if parent folder includes `tutorials` in the name (e.g. sap-tutorials/Tutorials-Contribution)

#### v0.4.13
- Validate <a href> links

#### v0.4.14
- Exclude links in code blocks from validation

#### v0.4.15
- Ignore empty URL fields in code lines and code blocks

#### v0.4.16
- Fix: image validation works incorrectly if there are more than one image on the same line
- Fix: installation script fails for non-admin Mac user

#### v0.4.18
- Add validation to warn about DONE button indentation

#### v0.4.19
- Fix: Test Tool doesn’t detect the line where invalid link was originally found (if there are several identical unreachable links on different lines)

#### v0.5.0
- Add menu item to insert an image into tutorial

#### v0.5.1
- Support remote images: ![Title](https://link.to.image.com)

#### v0.5.2
- Add _Code Block_ context menu item

#### v0.5.3
- Fix: npm error after installing atom plugin. Exclude package-lock.json from the production build 

#### v0.5.4
- Fix: _Push to Production_ fails in case of _stderr_ being _undefined_

#### v0.5.5
- Exclude localhost links from checking

#### v0.5.6
- Fix: http://localhost:8080 not caught as plain text URL

#### v0.5.7
- Support relative links to groups/missions

#### v0.5.8
- Fix: Plain text URL check takes too long

#### v0.5.9
- Support link syntax with a space between the braces: [Link] (http://link.com)

#### v0.5.10
- Support code blocks in notes (>)

#### v0.5.11
- Fix: URL Validator is not working for link format like: [URL](http://8031.2321.231.23180.com)

#### v0.5.12
- Fix: Image names with spaces not caught by validation

#### v0.5.13
- Validate metadata

#### v0.5.14
- Fix: push to QA/Production proceeds regardless of the validation result

#### v0.5.15
- Push to QA: Provide a way to provide the link to QA tutorial so author can copy and paste link from the message

#### v0.5.16
- Fix: Push to Production fails if a subfolder has been removed

#### v0.5.17
- Fix: Image names with `<` character are not validated

#### v0.5.18
- Fix: Test tool follows redirect URLs instead of checking an initial status code

#### v0.5.19
- Fix regression after: Test tool follows redirect URLs instead of checking an initial status code

#### v0.5.20
- Fix: Primary tag validation shows false positive if a tag contains a comma followed by a space.

#### v0.5.21
- Support paths to repositories including spaces in folder names

#### v0.5.22
- Update _Push to QA_ success notification

#### v0.5.23
- Fix quotes in _Push to Production_ commit message

#### v0.5.24
- Fix: if user uses SSH, link to pull request is wrong (push to production)

#### v0.5.25
- Suppress 'git pull' stdout

#### v0.6.0
- Optimize build process, add minification, reduce time added to Atom startup time

#### v0.6.1
- Improve installation flow

#### v0.6.2
- Add an icon indicating update status to the footer bar

#### v0.6.3
- Preview: wait for config.liveUpdateDelay ms to pass before refreshing preview tab

#### v0.6.4
- Preview: complete: wait for config.liveUpdateDelay ms to pass before refreshing preview tab

#### v0.6.5
- Auto-update: if the plugin is up-to-date, user can click on the icon and the plugin will check for updates;
  watch the value of Auto-update checkbox, if unset - disable icon, if set - check for updates

#### v0.6.6
- Fix code style errors
