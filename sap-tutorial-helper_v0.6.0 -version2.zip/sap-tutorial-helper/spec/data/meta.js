module.exports = {
  fileName: {
    metaTag: false,
    values: [
      {
        isValid: false,
        value: '',
      },
      {
        isValid: false,
        value: 'AAAAAAAAAA',
      },
      {
        isValid: true,
        value: 'aaa-test',
      },
    ],
  },
  title: {
    metaTag: true,
    values: [{
      value: 'aaa-test',
      isValid: true,
    }],
  },
  description: {
    metaTag: true,
    values: [{
      value: '',
      isValid: true,
    }],
  },
  time: {
    metaTag: true,
    values: [
      {
        value: 'eee',
        isValid: false,
      },
      {
        value: 'str',
        isValid: false,
      },
      {
        value: 60,
        isValid: true,
      },
    ],
  },
  levelTag: {
    metaTag: true,
    values: [
      {
        value: '',
        isValid: false,
      },
      {
        value: 'Beginner; Intermediate',
        isValid: false,
      },
      {
        value: 'Beginner',
        isValid: true,
      },
    ],
  },
  primaryTag: {
    metaTag: true,
    values: [
      {
        value: '',
        isValid: false,
      },
      {
        value: 'iOS; Android',
        isValid: false,
      },
      {
        value: 'iOS; sfsdfdsf',
        isValid: false,
      },
      {
        value: 'iOS',
        isValid: true,
      },
    ],
  },
  tags: {
    name: 'tags',
    metaTag: true,
    values: [
      {
        value: '',
        isValid: false,
      },
      {
        value: 'unknown tag',
        isValid: false,
      },
      {
        value: 'iOS',
        isValid: true,
      },
    ],
  },
};
