'use babel';

import path from 'path';
import fs from 'fs';
import util from 'util';

import constants from '../lib/constants';
import AddDialog from '../lib/modules/tutorial-creator/view-providers/tutorial-creation/add-dialog';
import meta from '../spec/data/meta';

import tutorialCreator from '../lib/modules/tutorial-creator';

import { dispatchCommand, setAutoUpdate, setQaRepoPath, spyOnExec } from './spec-helper';

const { COMMON, CLASS_NAMES } = constants;

const unlinkAsync = util.promisify(::fs.unlink);
const existsAsync = function existsAsync(filePath) {
  return new Promise(resolve => fs.exists(filePath, value => resolve(value)));
};

describe(`${PLUGIN_NAME}:create-tutorial`, () => {
  const CREATE_TUTORIAL_COMMAND = `${PLUGIN_NAME}:create-tutorial`;
  const CONFIRM_COMMAND = 'core:confirm';
  const CANCEL_COMMAND = 'core:cancel';
  const AUTOCOMPLETE_PLUGIN = 'autocomplete-plus';

  let workspaceElement;
  let dialogPanel;
  const parentElement = document.createElement('div');
  const childElement = document.createElement('div');

  tutorialCreator.watchEditor = () => {};
  parentElement.classList.add('directory');
  parentElement.classList.add('selected');
  parentElement.setAttribute('is', 'tree-view-directory');
  parentElement.appendChild(childElement);

  function prepareEnv() {
    setAutoUpdate();
    setQaRepoPath();
    waitsForPromise('autocomplete-plus package activation', () => atom.packages.activatePackage(AUTOCOMPLETE_PLUGIN));
    waitsForPromise('package activation', () => atom.packages.activatePackage(COMMON.PLUGIN_NAME));

    spyOnExec();

    workspaceElement = atom.views.getView(atom.workspace);
    jasmine.attachToDOM(workspaceElement);
    workspaceElement.appendChild(parentElement);
    // by default it has height 0
    workspaceElement.style.minHeight = `${document.body.clientHeight}px`;
  }

  describe('Dispatching create-tutorial command. WIP', () => {
    beforeEach(() => {
      childElement.setAttribute('data-name', COMMON.WIP_DIR_NAME);
      const TEMP_DIR_PATH = path.join(__dirname, COMMON.QA_TUTORIALS_GIT_REPO, COMMON.WIP_DIR_NAME);
      childElement.setAttribute('data-path', TEMP_DIR_PATH);

      setQaRepoPath();
      waitsForPromise('autocomplete-plus package activation', () => atom.packages.activatePackage(AUTOCOMPLETE_PLUGIN));
      waitsForPromise('package activation', () => atom.packages.activatePackage(COMMON.PLUGIN_NAME));

      spyOnExec();

      workspaceElement = atom.views.getView(atom.workspace);
      jasmine.attachToDOM(workspaceElement);
      workspaceElement.appendChild(parentElement);
      // by default it has height 0
      workspaceElement.style.minHeight = `${document.body.clientHeight}px`;

      spyOn(tutorialCreator, 'createTutorial');

      dispatchCommand(childElement, CREATE_TUTORIAL_COMMAND);
    });

    afterEach(function () {
      this.removeAllSpies();
    });

    it('should call handler', () => expect(tutorialCreator.createTutorial)
      .toHaveBeenCalled());
  });

  describe('Dispatching create-tutorial command. tutorials', () => {
    beforeEach(() => {
      childElement.setAttribute('data-name', 'tutorials');
      const TEMP_DIR_PATH = path.join(__dirname, COMMON.QA_TUTORIALS_GIT_REPO, 'tutorials');
      childElement.setAttribute('data-path', TEMP_DIR_PATH);

      setQaRepoPath();
      waitsForPromise('autocomplete-plus package activation', () => atom.packages.activatePackage(AUTOCOMPLETE_PLUGIN));
      waitsForPromise('package activation', () => atom.packages.activatePackage(COMMON.PLUGIN_NAME));

      spyOnExec();

      workspaceElement = atom.views.getView(atom.workspace);
      jasmine.attachToDOM(workspaceElement);
      workspaceElement.appendChild(parentElement);
      // by default it has height 0
      workspaceElement.style.minHeight = `${document.body.clientHeight}px`;

      spyOn(tutorialCreator, 'createTutorial');

      dispatchCommand(childElement, CREATE_TUTORIAL_COMMAND);
    });

    afterEach(function () {
      this.removeAllSpies();
    });

    it('should call handler', () => expect(tutorialCreator.createTutorial)
      .toHaveBeenCalled());
  });

  describe('Events: cancel', () => {
    childElement.setAttribute('data-name', 'work-in-progress');
    const TEMP_DIR_PATH = path.join(__dirname, COMMON.QA_TUTORIALS_GIT_REPO, 'work-in-progress');
    childElement.setAttribute('data-path', TEMP_DIR_PATH);

    beforeEach(() => {
      prepareEnv();
      waitsForPromise('handler to be called', () => tutorialCreator.createTutorial({ target: childElement }));
    });

    it('should close dialog on core:cancel', () => {
      dialogPanel = atom.workspace.getModalPanels()
        .find(panel => panel.item instanceof AddDialog);
      expect(dialogPanel)
        .toBeDefined();
      const { element: dialogElement } = dialogPanel.item;

      dispatchCommand(dialogElement, CANCEL_COMMAND);

      waitsFor('wait for panel to be destroyed', () => !atom.workspace.getModalPanels()
        .some(panel => panel.item instanceof AddDialog));

      runs(() => {
        dialogPanel = atom.workspace.getModalPanels()
          .find(panel => panel.item instanceof AddDialog);
        expect(dialogPanel)
          .not
          .toBeTruthy();
      });
    });
  });

  describe('Step validation', () => {
    childElement.setAttribute('data-name', 'tutorials');
    const TEMP_DIR_PATH = path.join(__dirname, COMMON.QA_TUTORIALS_GIT_REPO, 'tutorials');
    childElement.setAttribute('data-path', TEMP_DIR_PATH);

    beforeEach(() => {
      prepareEnv();
      waitsForPromise('handler to be called', () => tutorialCreator.createTutorial({ target: childElement }));
    });

    const result = {};
    let generator;

    function* testMetaInput() {
      const entries = Object.entries(meta);

      for (const entry of entries) {
        const [name, metaItem] = entry;

        for (const item of metaItem.values) {
          dialogPanel = atom.workspace.getModalPanels()
            .find(panel => panel.item instanceof AddDialog);

          const { miniEditor: editor, element: dialogElement } = dialogPanel.item;

          // clear previous input
          editor.setText('');
          editor.setText(item.value);

          dispatchCommand(dialogElement, CONFIRM_COMMAND);

          let isLast = false;
          waitsFor(`${name} with value ${item.value} to be reflected as error`, () => {
            dialogPanel = atom.workspace.getModalPanels()
              .find(panel => panel.item instanceof AddDialog);

            if (!dialogPanel) {
              // last dialog confirmed?
              isLast = true;
              return true;
            }

            const errorElement = dialogPanel.element.querySelector(`.${CLASS_NAMES.ERROR_MESSAGE}`);
            return !!errorElement.textContent === !item.isValid;
          });

          yield runs(() => {
            if (!isLast) {
              const errorElement = dialogPanel.element.querySelector(`.${CLASS_NAMES.ERROR_MESSAGE}`);

              if (item.isValid) {
                // save correct answer
                result[name] = item.value;
                // should destroy panel
                expect(dialogPanel)
                  .not
                  .toExist();
              } else {
                // should show the error
                expect(!!errorElement.textContent)
                  .toBe(!item.isValid);
              }
            }

            result.done = generator.next().done;
          });
        }
      }
    }

    it('should create folder with file inside', () => {
      generator = testMetaInput();
      generator.next();

      let dirPath;
      let filePath;
      let rulesPath;

      waitsFor(() => !!result.fileName);

      runs(() => {
        dirPath = path.join(TEMP_DIR_PATH, result.fileName);
        filePath = path.join(dirPath, `${result.fileName}.md`);
        rulesPath = path.join(dirPath, COMMON.RULES_FILE_NAME);
      });

      waitsFor(() => result.done && fs.existsSync(rulesPath));

      runs(async () => {
        expect(await existsAsync(dirPath))
          .toBe(true);

        expect(await existsAsync(filePath))
          .toBe(true);

        expect(await existsAsync(rulesPath))
          .toBe(true);

        if (result.done) {
          if (await existsAsync(filePath)) {
            await unlinkAsync(filePath);
          }

          if (await existsAsync(rulesPath)) {
            await unlinkAsync(rulesPath);
          }

          fs.rmdirSync(dirPath);
        }
      });
    });
  });

  describe('In Production repo', () => {
    const TEMP_DIR_PATH = path.join(__dirname, COMMON.PROD_TUTORIALS_GIT_REPO, 'tutorials');

    beforeEach(() => {
      childElement.setAttribute('data-path', TEMP_DIR_PATH);
      childElement.setAttribute('data-name', 'tutorials');
      setQaRepoPath();
      waitsForPromise('autocomplete-plus package activation', () => atom.packages.activatePackage(AUTOCOMPLETE_PLUGIN));
      waitsForPromise('package activation', () => atom.packages.activatePackage(COMMON.PLUGIN_NAME));

      workspaceElement = atom.views.getView(atom.workspace);
      jasmine.attachToDOM(workspaceElement);

      // by default it has height 0
      workspaceElement.style.minHeight = `${document.body.clientHeight}px`;

      spyOn(tutorialCreator, 'createTutorial');

      atom.commands.dispatch(childElement, CREATE_TUTORIAL_COMMAND);
    });

    it('should not call listener', () => expect(tutorialCreator.createTutorial)
      .not
      .toHaveBeenCalled());
  });
});
