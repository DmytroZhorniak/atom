'use babel';

import path, { sep } from 'path';

import { dialog } from 'remote';
import constants from '../lib/constants';
import autoUpdate from '../lib/modules/auto-update';
import { setAutoUpdate, setQaRepoPath } from './spec-helper';

const { COMMON, MESSAGES } = constants;
const qaRepoConfigKey = COMMON.QA_REPO_CWD_CONFIG_KEY;

describe(`${PLUGIN_NAME}. Auto-update`, () => {
  /**
   * Names of suites are important and used across code, try not to change them
   * spyOn sends all the calls to the first defined callback,
   * so there was no chance to write it all in a right way
   * */
  describe('Update', () => {
    function prepareCommand(command) {
      /* we will take only 2 words of command */
      if (command.split(/\s/).length > 2) {
        const result = command.split(/\s/);
        result.splice(2);
        return result.join(' ');
      }

      return command;
    }

    const result = {
      noUpdates: {
        commands: [],
      },
      fetchError: {
        commands: [],
      },
      stdError: {
        commands: [],
      },
      installCancelled: {
        commands: [],
      },
      installConfirmed: {
        commands: [],
      },
      keys: ['noUpdates', 'fetchError', 'stdError', 'installCancelled', 'installConfirmed'],
      reset() {
        Object.keys(this)
          .forEach((key) => {
            if (this.keys.includes(key)) {
              this[key] = {
                commands: [],
              };
            }
          });
      },
    };

    const handlers = {
      noUpdates: {
        handler(command) {
          command = prepareCommand(command);
          if (!result.noUpdates.commands.includes(command)) {
            result.noUpdates.commands.push(command);
          }
          return ({
            stderr: '',
            stdout: '',
          });
        },
        // we cannot create spy before activation
        getCommands: () => (['git fetch', 'git pull']),
        newVersion: false,
      },
      fetchError: {
        handler(command) {
          command = prepareCommand(command);

          if (!result.fetchError.commands.includes(command)) {
            result.fetchError.commands.push(command);
          }

          throw (new Error('Error'));
        },
        getCommands: () => ['git fetch'],
        newVersion: undefined,
      },
      installCancelled: {
        handler(command) {
          command = prepareCommand(command);

          if (!result.installCancelled.commands.includes(command)) {
            result.installCancelled.commands.push(command);
          }

          if (this.commands.has(command)) {
            return this.commands.get(command)
              .handler(command);
          } else {
            console.log('Unsupported installCancelled commands', command);
          }
        },
        newVersion: '1111.1111.1111',
        commands: new Map([
          ['git fetch', {
            handler: () => ({
              stdout: '',
              stderr: '',
            }),
          }],
          ['git pull', {
            handler: () => ({
              stdout: '',
              stderr: '',
            }),
          }],
        ]),
        getCommands() {
          return ['git fetch', 'git pull'];
        },
      },
      installConfirmed: {
        handler(command) {
          command = prepareCommand(command);

          if (!result.installConfirmed.commands.includes(command)) {
            result.installConfirmed.commands.push(command);
          }

          if (this.commands.has(command)) {
            return this.commands.get(command)
              .handler(command);
          }
        },
        newVersion: '1111.1111.1111',
        commands: new Map([
          ['git fetch', {
            handler: () => ({
              stdout: '',
              stderr: '',
            }),
          }],
          ['git pull', {
            handler: () => ({
              stdout: '',
              stderr: '',
            }),
          }],
        ]),
        getCommands() {
          return ['git fetch', 'git pull'];
        },
      },
    };

    beforeEach(() => {
      setQaRepoPath();
      setAutoUpdate(true);

      spyOn(autoUpdate.executor, 'exec')
        .andCallFake((...args) => {
          const { description: key } = jasmine.currentEnv_.currentSpec.suite;
          if (!handlers[key]) {
            return;
          }

          return handlers[key].handler(...args);
        });

      spyOn(atom, 'confirm')
        .andCallFake((options, callback) => {
          const { description: key } = jasmine.currentEnv_.currentSpec.suite;
          console.log(key, ' key in atom.confirm');
          if (key === 'installCancelled') {
            callback(1);
          } else {
            callback(0);
          }
        });

      spyOn(autoUpdate, 'getNewVersion')
        .andCallFake(() => {
          const { description: key } = jasmine.currentEnv_.currentSpec.suite;

          return handlers[key].newVersion;
        });
      waitsForPromise(() => atom.packages.activatePackage(COMMON.PLUGIN_NAME));

      waitsFor(() => !!autoUpdate.executor);

      waitsFor(() => autoUpdate.executor.exec.callCount > 0, 'autoUpdate.executor.exec.callCount > 0', 5000);
    });

    describe('noUpdates', () => {
      it('should call childProcess.exec with git fetch and git diff only', () => {
        const isValid = result.noUpdates
          .commands.every(i => handlers.noUpdates.getCommands()
            .includes(i));

        expect(isValid)
          .toBeTruthy();
      });

      it('should call only two commands', () => {
        expect(result.noUpdates.commands)
          .toHaveLength(handlers.noUpdates.getCommands().length);
      });
    });

    describe('fetchError', () => {
      it('should call childProcess.exec with git fetch and only', () => {
        const isValid = result.fetchError
          .commands.every(i => handlers.fetchError.getCommands()
            .includes(i));

        expect(isValid)
          .toBeTruthy();
      });

      it('should call only two commands', () => {
        expect(result.fetchError.commands)
          .toHaveLength(handlers.fetchError.getCommands().length);
      });

      it('should show notification warning', () => {
        const notifications = atom.notifications.getNotifications();
        const exists = notifications.some(
          n => n.message === MESSAGES.AUTO_UPDATE.NOTIFICATIONS.FAILURE
        );

        expect(exists)
          .toBe(true);
      });
    });

    describe('installCancelled', () => {
      it('should call atom.confirm', () => {
        waitsFor(() => atom.confirm.callCount > 0, 'atom.confirm.callCount > 0', 5000);

        runs(() => {
          expect(atom.confirm)
            .toHaveBeenCalled();
        });
      });

      it('should call only git fetch, diff', () => {
        const isValid = result.installCancelled
          .commands.every(i => handlers.installCancelled.getCommands()
            .includes(i));

        expect(isValid)
          .toBeTruthy();
      });

      it('should call only two commands', () => {
        expect(result.installCancelled.commands)
          .toHaveLength(handlers.installCancelled.getCommands().length);
      });
    });

    describe('installConfirmed', () => {
      it('should call atom.confirm', () => {
        waitsFor(() => atom.confirm.callCount > 0, 'atom.confirm.callCount > 0', 5000);

        runs(() => {
          expect(atom.confirm)
            .toHaveBeenCalled();
        });
      });

      it('should call atom.confirm twice', () => {
        waitsFor(() => atom.confirm.callCount > 0, 'atom.confirm.callCount > 0', 5000);
        runs(() => {
          expect(atom.confirm.callCount)
            .toEqual(2);
        });
      });

      it('should call only all commands', () => {
        const isValid = result.installConfirmed
          .commands.every(i => handlers.installConfirmed.getCommands()
            .includes(i));

        expect(isValid)
          .toBeTruthy();
      });

      it('should call all needed amount of commands', () => {
        expect(result.installConfirmed.commands)
          .toHaveLength(handlers.installConfirmed.getCommands().length);
      });
    });
  });

  describe('Ask for path to repo', () => {
    function prepareEnv(handlers) {
      setAutoUpdate(true);
      atom.config.unset(qaRepoConfigKey);

      waitsForPromise('package activation', () => atom.packages.activatePackage(COMMON.PLUGIN_NAME));

      spyOn(atom, 'confirm')
        .andCallFake(handlers.confirm);
      spyOn(dialog, 'showOpenDialog')
        .andCallFake(handlers.showOpenDialog);
    }

    describe('With preset path', () => {
      beforeEach(() => {
        setAutoUpdate(true);
        setQaRepoPath();
        spyOn(atom, 'confirm');
      });

      it('should not call atom.confirm', () => expect(atom.confirm)
        .not
        .toHaveBeenCalled());
    });

    describe('With preset invalid path', () => {
      beforeEach(() => {
        setAutoUpdate(true);
        atom.config.unset(qaRepoConfigKey);
        atom.config.set(qaRepoConfigKey, `lorem${sep}ipsum${sep}dolor`);
        spyOn(atom, 'confirm').andCallFake(callback => callback(0));
        waitsForPromise('package activation', () => autoUpdate.activate());
        waitsFor(() => atom.confirm.callCount > 0);
      });

      it('should call atom.confirm', () => runs(() => expect(atom.confirm)
        .toHaveBeenCalled()));
    });

    describe('With empty path in config: entering path cancelled', () => {
      const handlers = {
        confirm: (options, callback) => callback(1),
        showOpenDialog: (options, callback) => callback([]),
      };

      beforeEach(() => prepareEnv(handlers));

      it('should call atom.confirm', () => expect(atom.confirm)
        .toHaveBeenCalled());

      it('should call dialog.showOpenDialog', () => expect(dialog.showOpenDialog)
        .not
        .toHaveBeenCalled());

      it('should show notification warning', () => {
        waitsFor(() => atom.notifications.getNotifications().length > 0);

        runs(() => {
          const notifications = atom.notifications.getNotifications();
          const exists = notifications.some(
            n => n.options.detail === MESSAGES.AUTO_UPDATE.NOTIFICATIONS.NO_REPO_PATH_SELECTED
          );

          expect(exists)
            .toBe(true);
        });
      });
    });

    describe('With empty path in config: wrong path chosen', () => {
      const handlers = {
        confirm: (options, callback) => callback(0),
        showOpenDialog: (options, callback) => callback([__dirname]),
      };
      beforeEach(() => prepareEnv(handlers));

      it('should call atom.confirm', () => {
        expect(atom.confirm)
          .toHaveBeenCalled();
      });

      it('should call dialog.showOpenDialog', () => {
        expect(dialog.showOpenDialog)
          .toHaveBeenCalled();
      });

      it('should not set config value', () => {
        const configValue = atom.config.get(qaRepoConfigKey);

        expect(configValue)
          .not
          .toExist();
      });

      it('should show notification about invalid repo', () => {
        const notifications = atom.notifications.getNotifications();
        const exists = notifications.some(
          n => n.options.detail === MESSAGES.AUTO_UPDATE.NOTIFICATIONS.INVALID_REPO
        );

        expect(exists)
          .toBe(true);
      });
    });

    describe('With empty path in config: not existing path chosen', () => {
      const handlers = {
        confirm: (options, callback) => callback(0),
        showOpenDialog: (options, callback) => callback([`${__dirname}${sep}wrong${sep}${COMMON.QA_TUTORIALS_GIT_REPO}`]),
      };
      beforeEach(() => prepareEnv(handlers));

      it('should call atom.confirm', () => {
        expect(atom.confirm)
          .toHaveBeenCalled();
      });

      it('should call dialog.showOpenDialog', () => {
        expect(dialog.showOpenDialog)
          .toHaveBeenCalled();
      });

      it('should not set config value', () => {
        const configValue = atom.config.get(qaRepoConfigKey);

        expect(configValue)
          .not
          .toExist();
      });

      it('should show notification about invalid repo', () => {
        const notifications = atom.notifications.getNotifications();
        const exists = notifications.some(
          n => n.options.detail === MESSAGES.AUTO_UPDATE.NOTIFICATIONS.INVALID_REPO
        );

        expect(exists)
          .toBe(true);
      });
    });

    describe('With empty path in config: valid path chosen', () => {
      const handlers = {
        confirm: (options, callback) => callback(0),
        showOpenDialog: (options, callback) => callback([
          path.join(
            PLUGIN_HOME,
            'spec',
            COMMON.QA_TUTORIALS_GIT_REPO
          ),
        ]),
      };

      beforeEach(() => {
        prepareEnv(handlers);
        spyOn(atom, 'open');
      });

      it('should call atom.confirm', () => {
        expect(atom.confirm)
          .toHaveBeenCalled();
      });

      it('should call dialog.showOpenDialog', () => {
        expect(dialog.showOpenDialog)
          .toHaveBeenCalled();
      });
      it('should set config value', () => {
        const configValue = atom.config.get(qaRepoConfigKey);

        expect(configValue)
          .toBeDefined();
      });
      it('should call atom.open', () => {
        waitsFor(() => atom.open.callCount > 0);
        runs(() => {
          expect(atom.open)
            .toHaveBeenCalled();
        });
      });
    });
  });
});
