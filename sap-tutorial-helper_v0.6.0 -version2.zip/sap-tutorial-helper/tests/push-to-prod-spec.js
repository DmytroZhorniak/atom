'use babel';

import path, { sep } from 'path';
import { dialog } from 'remote';
import constants from '../lib/constants';
import { atomHelpers } from '../lib/helpers';
import commitSelectionModule from '../lib/modules/commit-selection';
import pushToProd from '../lib/modules/push-to-prod';

import { setAutoUpdate, setForkRepoPath, setQaRepoPath, } from './spec-helper';

const { COMMON, MESSAGES } = constants;

const configKey = COMMON.PROD_REPO_CWD_CONFIG_KEY;

describe(`${PLUGIN_NAME}. Push to Production`, () => {
  const PUSH_TO_PROD_COMMAND = `${PLUGIN_NAME}:push-to-prod`;
  const TUTORIAL_NAME = 'tutorial-name';

  const parentElement = document.createElement('div');
  const tutorialElement = document.createElement('div');

  parentElement.appendChild(tutorialElement);
  parentElement.classList.add('directory');
  tutorialElement.setAttribute('data-path', path.join(PLUGIN_HOME, 'spec', COMMON.TUTORIALS_DIR_NAME, TUTORIAL_NAME));

  function prepareEnv(handlers) {
    spyOn(commitSelectionModule, 'validate')
      .andCallFake(() => Promise.resolve());
    spyOn(pushToProd, 'getDeletedFiles')
      .andCallFake(() => Promise.resolve([]));
    spyOn(atomHelpers, 'getOriginUrl')
      .andReturn('some url');
    spyOn(atomHelpers, 'getRepo')
      .andReturn({ getWorkingDirectory: () => path.join(PLUGIN_HOME, 'spec') });

    waitsForPromise({
      shouldReject: false,
      label: 'our package activation',
    }, () => atom.packages.activatePackage(COMMON.PLUGIN_NAME));

    setAutoUpdate(false);

    const workspaceElement = atom.views.getView(atom.workspace);
    jasmine.attachToDOM(workspaceElement);
    workspaceElement.style.minHeight = `${document.body.clientHeight}px`;

    workspaceElement.appendChild(parentElement);

    if (handlers) {
      spyOn(atom, 'confirm')
        .andCallFake(handlers.confirm);
      spyOn(dialog, 'showOpenDialog')
        .andCallFake(handlers.showOpenDialog);
    }

    pushToProd.consumeTreeView({
      selectedPaths: () => [path.join(PLUGIN_HOME, 'spec', 'Tutorials-Contribution', COMMON.TUTORIALS_DIR_NAME, 'some-tutorial')],
    });

    commitSelectionModule.consumeTreeView({
      selectedPaths: () => [path.join(PLUGIN_HOME, 'spec', 'Tutorials-Contribution', COMMON.TUTORIALS_DIR_NAME, 'some-tutorial')],
    });
    setQaRepoPath();
    spyOn(commitSelectionModule, 'checkCwd').andReturn(path.join(PLUGIN_HOME, 'spec', 'Tutorials-Contribution'));
  }

  const dispatchPushCommand = () => {
    let called = false;

    const disposable = atom.commands.onDidDispatch(({ type }) => {
      if (type === PUSH_TO_PROD_COMMAND) {
        called = true;
        disposable.dispose();
      }
    });
    atom.commands.dispatch(tutorialElement, PUSH_TO_PROD_COMMAND);

    waitsFor(() => called, `${PUSH_TO_PROD_COMMAND} to be called`);
  };

  describe('With empty path in config: entering path cancelled', () => {
    const handlers = {
      confirm: (options, callback) => callback(1),
      showOpenDialog: (options, callback) => callback([]),
    };

    beforeEach(() => prepareEnv(handlers));

    it('should call atom.confirm', () => {
      atom.config.unset(configKey);
      dispatchPushCommand();
      runs(() => expect(atom.confirm)
        .toHaveBeenCalled());
    });

    it('should call dialog.showOpenDialog', () => {
      dispatchPushCommand();

      runs(() => expect(dialog.showOpenDialog)
        .not
        .toHaveBeenCalled());
    });

    it('should show notification warning', () => {
      dispatchPushCommand();

      waitsFor(() => atom.notifications.getNotifications().length > 0);

      runs(() => {
        const notifications = atom.notifications.getNotifications();
        const exists = notifications.some(
          n => n.options.detail === MESSAGES.PUSH_TO_PROD.NOTIFICATIONS.NO_REPO_PATH_SELECTED
        );

        expect(exists)
          .toBe(true);
      });
    });
  });

  describe('With empty path in config: wrong path chosen', () => {
    const handlers = {
      confirm: (options, callback) => callback(0),
      showOpenDialog: (options, callback) => callback([__dirname]),
    };
    beforeEach(() => prepareEnv(handlers));

    it('should call atom.confirm', () => {
      dispatchPushCommand();

      waitsFor(() => dialog.showOpenDialog.callCount > 0);
      runs(() => {
        expect(atom.confirm)
          .toHaveBeenCalled();
        expect(dialog.showOpenDialog)
          .toHaveBeenCalled();
      });
    });

    it('should not set config value', () => {
      dispatchPushCommand();

      const configValue = atom.config.get(configKey);

      runs(() => expect(configValue)
        .not
        .toExist());
    });

    it('should show notification about invalid repo', () => {
      dispatchPushCommand();

      waitsFor(() => atom.notifications.getNotifications().length > 0);

      runs(() => {
        const notifications = atom.notifications.getNotifications();
        const exists = notifications.some(
          n => n.options.detail === MESSAGES.PUSH_TO_PROD.NOTIFICATIONS.INVALID_REPO
        );

        expect(exists)
          .toBe(true);
      });
    });
  });

  describe('With empty path in config: not existing path chosen', () => {
    const handlers = {
      confirm: (options, callback) => callback(0),
      showOpenDialog: (options, callback) => callback([`${__dirname}${sep}wrong${sep}${COMMON.PROD_TUTORIALS_GIT_REPO}`]),
    };
    beforeEach(() => prepareEnv(handlers));

    it('should call atom.confirm', () => {
      dispatchPushCommand();

      waitsFor(() => dialog.showOpenDialog.callCount > 0);
      runs(() => {
        expect(atom.confirm)
          .toHaveBeenCalled();
        expect(dialog.showOpenDialog)
          .toHaveBeenCalled();
      });
    });

    it('should not set config value', () => {
      dispatchPushCommand();

      const configValue = atom.config.get(configKey);

      runs(() => expect(configValue)
        .not
        .toExist());
    });

    it('should show notification about invalid repo', () => {
      dispatchPushCommand();

      runs(() => {
        const notifications = atom.notifications.getNotifications();
        const exists = notifications.some(
          n => n.options.detail === MESSAGES.PUSH_TO_PROD.NOTIFICATIONS.INVALID_REPO
        );

        expect(exists)
          .toBe(true);
      });
    });
  });

  describe('With preset path: no errors', () => {
    function extractCommand(command) {
      // two first words are important
      const commandArray = command.split(' ');
      commandArray.splice(2);
      return commandArray.join(' ');
    }

    if (!pushToProd.executor) {
      pushToProd.executor = {
        exec: () => {
          return {
            stdout: '',
            stderr: '',
          };
        },
        runCommand() {
          return this.exec();
        },
      };
    }

    if (!commitSelectionModule.executor) {
      commitSelectionModule.executor = {
        exec: () => {
          return {
            stdout: '',
            stderr: '',
          };
        },
        runCommand() {
          return this.exec();
        },
      };
    }

    beforeEach(() => {
      setForkRepoPath();
      prepareEnv();
      // prevent from calling fs
      spyOn(pushToProd, 'copyToForkDir');
    });

    afterEach(function () {
      this.removeAllSpies();
    });

    it('should call check status, pull and merge', () => {
      const commands = new Set();

      spyOn(pushToProd.executor, 'exec')
        .andCallFake((command) => {
          commands.add(extractCommand(command));
          return Promise.resolve({
            stdout: '',
            stderr: '',
          });
        });

      spyOn(pushToProd.executor, 'runCommand')
        .andCallFake((command) => {
          commands.add(extractCommand(command));
          return Promise.resolve({
            stdout: '',
            stderr: '',
          });
        });

      dispatchPushCommand();

      waitsFor(() => pushToProd.executor.exec.callCount > 1);

      runs(() => {
        expect(commands.has('git status'))
          .toBe(true);
        expect(commands.has('git pull'))
          .toBe(true);
        expect(commands.has('git merge'))
          .toBe(true);
      });
    });

    it('should copy to fork', () => {
      dispatchPushCommand();

      runs(() => {
        spyOn(pushToProd.executor, 'exec')
          .andCallFake(() => Promise.resolve({
            stdout: '',
            stderr: '',
          }));

        spyOn(pushToProd.executor, 'runCommand')
          .andCallFake(() => Promise.resolve({
            stdout: '',
            stderr: '',
          }));
      });

      waitsFor(() => pushToProd.executor.exec.callCount > 3, 'waiting for pushToProd.executor.exec.callCount > 3');

      runs(() => expect(pushToProd.copyToForkDir)
        .toHaveBeenCalled());
    });

    it('should dispatch commit selection if commit confirmed', () => {
      spyOn(commitSelectionModule, 'commitSelection')
        .andCallThrough();

      spyOn(pushToProd.executor, 'exec')
        .andCallFake((command) => {
          if (command.startsWith('git status')) {
            return Promise.resolve({ stdout: 'M some-file' });
          }
          return Promise.resolve({
            stdout: '',
            stderr: '',
          });
        });

      spyOn(pushToProd.executor, 'runCommand')
        .andCallFake((command) => {
          if (command.startsWith('git status')) {
            return Promise.resolve({ stdout: 'M some-file' });
          }
          return Promise.resolve({
            stdout: '',
            stderr: '',
          });
        });

      spyOn(commitSelectionModule.executor, 'exec')
        .andCallFake((command) => {
          if (command.startsWith('git status')) {
            return Promise.resolve({ stdout: 'M some-file' });
          }
          return Promise.resolve({
            stdout: '',
            stderr: '',
          });
        });

      spyOn(commitSelectionModule.executor, 'runCommand')
        .andCallFake((command) => {
          if (command.startsWith('git status')) {
            return Promise.resolve({ stdout: 'M some-file' });
          }
          return Promise.resolve({
            stdout: '',
            stderr: '',
          });
        });

      spyOn(atom, 'confirm')
        .andCallFake((options, callback) => callback(0));
      dispatchPushCommand();

      waitsFor(() =>
        commitSelectionModule.commitSelection.callCount > 0,
        'commitSelectionModule.commitSelection.callCount > 0'
      );
      runs(() => expect(commitSelectionModule.commitSelection)
        .toHaveBeenCalled());
    });

    it('should not dispatch commit selection if commit not confirmed', () => {
      spyOn(pushToProd.executor, 'exec')
        .andCallFake((command) => {
          if (command.startsWith('git status')) {
            return Promise.resolve({ stdout: 'M some-file' });
          }
          return Promise.resolve({
            stdout: '',
            stderr: '',
          });
        });

      spyOn(pushToProd.executor, 'runCommand')
        .andCallFake((command) => {
          if (command.startsWith('git status')) {
            return Promise.resolve({ stdout: 'M some-file' });
          }
          return Promise.resolve({
            stdout: '',
            stderr: '',
          });
        });

      spyOn(commitSelectionModule.executor, 'exec')
        .andCallFake((command) => {
          if (command.startsWith('git status')) {
            return Promise.resolve({ stdout: 'M some-file' });
          }
          return Promise.resolve({
            stdout: '',
            stderr: '',
          });
        });

      spyOn(commitSelectionModule.executor, 'runCommand')
        .andCallFake((command) => {
          if (command.startsWith('git status')) {
            return Promise.resolve({ stdout: 'M some-file' });
          }
          return Promise.resolve({
            stdout: '',
            stderr: '',
          });
        });

      spyOn(atom, 'confirm')
        .andCallFake((options, callback) => callback(1));
      dispatchPushCommand();

      waitsFor(() => atom.notifications.getNotifications()
        .some(n => n.options.detail === MESSAGES.PUSH_TO_PROD.NOTIFICATIONS.CANNOT_PROCEED));

      runs(() => {
        const exists = atom.notifications.getNotifications()
          .some(n => n.options.detail === MESSAGES.PUSH_TO_PROD.NOTIFICATIONS.CANNOT_PROCEED);
        expect(exists)
          .toBe(true);
      });
    });

    it('should show success notification with the link', () => {
      spyOn(pushToProd.executor, 'exec')
        .andCallFake(() => Promise.resolve({
          stdout: '',
          stderr: '',
        }));

      spyOn(commitSelectionModule.executor, 'exec')
        .andCallFake((command) => {
          if (command.startsWith('git status')) {
            return Promise.resolve({ stdout: 'M some-file' });
          }
          return Promise.resolve({
            stdout: '',
            stderr: '',
          });
        });

      spyOn(commitSelectionModule.executor, 'runCommand')
        .andCallFake((command) => {
          if (command.startsWith('git status')) {
            return Promise.resolve({ stdout: 'M some-file' });
          }
          return Promise.resolve({
            stdout: '',
            stderr: '',
          });
        });
      dispatchPushCommand();

      waitsFor(() => atom.notifications.getNotifications().length > 0);

      runs(() => {
        const exists = atom.notifications.getNotifications()
          .some(n => n.message === MESSAGES.PUSH_TO_PROD.NOTIFICATIONS.END_SUCCESS_TITLE);

        expect(exists)
          .toBe(true);
      });
    });
  });

  describe('With preset path: errors', () => {
    beforeEach(() => {
      setForkRepoPath();
      prepareEnv();
      // prevent from calling fs
      spyOn(pushToProd, 'copyToForkDir');
    });

    it('should show error if error in stderr', () => {
      const errorMessage = 'error';

      if (!pushToProd.executor) {
        pushToProd.executor = {
          exec: () => {
          },
          runCommand() {
            return this.exec();
          },
        };
      }

      spyOn(pushToProd.executor, 'exec')
        .andCallFake(() => Promise.resolve({
          stderr: errorMessage,
          stdout: '',
        }));
      dispatchPushCommand();

      waitsFor(() => pushToProd.executor.exec.callCount > 0);

      waitsFor(() => atom.notifications.getNotifications().length > 0);

      runs(() => {
        const exists = atom.notifications.getNotifications()
          .some(n => n.message === MESSAGES.PUSH_TO_PROD.NOTIFICATIONS.FAILURE
            && n.options.detail === errorMessage);

        expect(exists)
          .toBe(true);
      });
    });

    it('should show error if rejected', () => {
      const errorMessage = 'error';

      spyOn(pushToProd.executor, 'exec')
        .andCallFake(() => Promise.resolve({
          stderr: new Error(errorMessage),
          stdout: '',
        }));
      dispatchPushCommand();

      waitsFor(() => atom.notifications.getNotifications().length > 0);

      runs(() => {
        const exists = atom.notifications.getNotifications()
          .some(n => n.message === MESSAGES.PUSH_TO_PROD.NOTIFICATIONS.FAILURE
            && n.options.detail === `Error: ${errorMessage}`);

        expect(exists)
          .toBe(true);
      });
    });

    it('should not call copy to fork', () => expect(pushToProd.copyToForkDir)
      .not
      .toHaveBeenCalled());
  });
});
