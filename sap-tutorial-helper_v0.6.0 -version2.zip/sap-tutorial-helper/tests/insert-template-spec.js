'use babel';

import path from 'path';

import templates from '../lib/modules/insert-template/templates';
import { dispatchCommand, setAutoUpdate, setQaRepoPath } from './spec-helper';

xdescribe('Insert Template Context Menu', () => {
  let editorElement;
  let editor;

  beforeEach(() => {
    setAutoUpdate();
    setQaRepoPath();
    waitsForPromise('package activation', () => atom.packages.activatePackage(COMMON.PLUGIN_NAME));
    waitsForPromise('package activation', () => atom.packages.activatePackage('language-gfm').then(console.log));
    const workspaceElement = atom.views.getView(atom.workspace);
    jasmine.attachToDOM(workspaceElement);
    waitsForPromise(async () => {
      const tutorialPath = path.join(PLUGIN_HOME, 'spec', 'data/valid.md');
      editor = await atom.workspace.open(tutorialPath);
      editorElement = editor.getElement();
      return editor;
    });
  });

  it('should display each menu item', () => {
    runs(() => {
      const items = atom.contextMenu.templateForElement(editorElement);
      const menuItems = ['Image', 'Link', 'Bulleted List', 'Ordered List', 'Table', 'Option Tab', 'Step', 'Validation'];
      const foundItems = items.filter(item => menuItems.includes(item.label));

      expect(foundItems)
        .toHaveLength(menuItems.length);
    });
  });

  it('should contain all submenus', () => {
    const items = atom.contextMenu.templateForElement(editorElement);

    const menuItems = {
      Link: ['With link text', 'Link text same as URL', 'Example link'],
      'Code Block': [
        'No Language',
        'ABAP',
        'Swift',
        'SQL',
        'HTML',
        'CSS',
        'JavaScript',
        'XML',
        'HTTP',
        'JSON',
        'INI',
        'Java',
        'C++',
        'Python',
        'R',
        'Shell / Bash',
        'YAML',
        'CDS',
      ],
      Validation: [
        'Text matches',
        'Text exactly matches',
        'Text starts with',
        'Text contains',
        'Text exactly matches with ID',
        'HTTP status code',
        'Custom Regex',
        'Question, single answer',
        'Question, multiple answer',
      ],
    };

    const allExist = items.filter((item) => {
      return Object
        .entries(menuItems)
        .every(([key, submenus]) => {
          if (key === item.label) {
            return item.submenu.every(submenu => submenus.includes(submenu.label));
          } else {
            return true;
          }
        });
    });

    expect(allExist)
      .toBeTruthy();
  });

  it('should insert proper template onClick', () => {
    const items = atom.contextMenu.templateForElement(editorElement);
    const commands = items.reduce(function getCommand(result, menuItem) {
      if (menuItem.command && menuItem.command.startsWith(`${PLUGIN_NAME}:insert-template`)) {
        return [...result, menuItem.command];
      } else if (menuItem.submenu) {
        return [...result, ...menuItem.submenu.reduce(getCommand, [])];
      } else {
        return result;
      }
    }, []);
    spyOn(editor, 'insertText');
    waitsForPromise(() => Promise
      .all(commands.map(command => dispatchCommand(editorElement, command))));

    waitsFor(() => editor.insertText.callCount > 1);
    runs(() => {
      expect(editor.insertText)
        .toHaveBeenCalled();
      expect(editor.insertText.callCount)
        .toEqual(commands.length);
      Object
        .values(templates)
        .forEach(templates => expect(editor.insertText)
          .toHaveBeenCalledWith(templates));
    });
  });
});
