const os = require('os');
const path = require('path');
const glob = require('glob');
const webpack = require('webpack');

const { name: PLUGIN_NAME } = require('./package');
const specs = glob.sync('./tests/*.js');

const entry = {
  'dist/main.js': './lib',
};

specs.reduce((result, filePath) => {
  entry[`spec/${path.basename(filePath)}`] = filePath;

  return entry;
}, entry);

const ATOM_DIR_NAME = '.atom';
const homedir = os.homedir().replace('.node-gyp', '');
const ATOM_HOME = homedir.includes(ATOM_DIR_NAME) ? homedir : path.join(homedir, '.atom');
const PLUGIN_HOME = path.join(ATOM_HOME, 'packages', PLUGIN_NAME);

module.exports = {
  mode: process.env.NODE_ENV || 'development',
  entry,
  output: {
    path: PLUGIN_HOME,
    filename: './[name]',
    library: '',
    libraryTarget: 'commonjs',
  },
  resolve: {
    alias: {
      static: path.resolve(PLUGIN_HOME, 'static/'),
      'static-fallback': path.resolve(PLUGIN_HOME, 'static-fallback/'),
    },
  },
  module: {
    rules: [
      {
        test: /\.m?js$/,
        exclude: /(node_modules)/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: [
              ['@babel/preset-env', {
                targets: {
                  chrome: 69,
                },
              }],
              '@babel/preset-react',
              'minify',
            ],
            plugins: [
              '@babel/plugin-proposal-export-default-from',
              'transform-function-bind',
            ],
          },
        },
      },
    ],
  },
  plugins: [
    new webpack.DefinePlugin({
      PLUGIN_NAME: JSON.stringify(PLUGIN_NAME),
      PLUGIN_HOME: JSON.stringify(PLUGIN_HOME),
    }),
  ],
  target: 'electron-renderer',
  externals: {
    atom: 'commonjs atom',
    'node-fetch': 'node-fetch',
  },
};
