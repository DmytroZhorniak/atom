module.exports = {
  invalid: {
    bufferRow: 7,
    decorations: 1,
  },
};
