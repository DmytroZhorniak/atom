#!/bin/bash

#Define env variables
ATOM_HOME=/Users/$USER/.atom
PACKAGE_FOLDER=sap-tutorial-helper

if [ -d $ATOM_HOME ]; then
    printf "Installing Atom SAP Tutorial plugin...\n\n"
    if [ ! -d $ATOM_HOME/packages ]; then
        mkdir $ATOM_HOME/packages
    fi
    cp -r $(dirname "${BASH_SOURCE[0]}")/.. $ATOM_HOME/packages/$PACKAGE_FOLDER
    cd $ATOM_HOME/packages/$PACKAGE_FOLDER
    rm -rf node_modules > /dev/null 2>&1
    printf "Installing dependencies"
    npm i
    npm audit fix > /dev/null 2>&1
    printf "Installation successfully completed!\n\n"
else
    printf "Atom installation not found!\n"
    printf "Please, check the following path $ATOM_HOME\n"
fi

read -n1 -r -p "Press any key to continue..." key
